import random

counter = 0
for _ in range(1000000):
    x = f"{str(random.randrange(0, 99999999)).zfill(8)}"
    print(" - ", end="")
    if x[6:8] <= "90":
        counter += 1
    print(x, end="")

print(f"\n\n{counter / 1000000}")


if self.current_room["torch_number"] != " you see no light sources.":
    self.description += f'{self.current_room["torches"]}{self.current_room["torch_number"]}dimly lights the room. '
